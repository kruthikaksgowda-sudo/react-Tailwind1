import React, { useState } from 'react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Logging in with email: ${email} and password: ${password}`);
  };

  return (
    <>
      <style>{`
        .login-container {
          min-height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          background: linear-gradient(135deg, #667eea, #764ba2);
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .login-box {
          background: white;
          padding: 40px 50px;
          border-radius: 12px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
          width: 360px;
          text-align: center;
        }

        .login-title {
          font-size: 2rem;
          margin-bottom: 24px;
          color: #333;
          font-weight: 700;
        }

        .login-form {
          display: flex;
          flex-direction: column;
          text-align: left;
        }

        .login-label {
          margin-bottom: 8px;
          font-weight: 600;
          color: #555;
        }

        .login-input {
          padding: 12px 15px;
          border: 2px solid #ddd;
          border-radius: 8px;
          margin-bottom: 20px;
          font-size: 1rem;
          transition: border-color 0.3s ease;
          outline: none;
        }

        .login-input:focus {
          border-color: #667eea;
          box-shadow: 0 0 8px rgba(102, 126, 234, 0.5);
        }

        .login-button {
          background: #667eea;
          color: white;
          font-weight: 700;
          padding: 14px;
          border: none;
          border-radius: 10px;
          font-size: 1.1rem;
          cursor: pointer;
          transition: background 0.3s ease;
          box-shadow: 0 8px 15px rgba(102, 126, 234, 0.4);
        }

        .login-button:hover {
          background: #5563c1;
          box-shadow: 0 12px 20px rgba(85, 99, 193, 0.6);
        }
      `}</style>

      <div className="login-container">
        <div className="login-box">
          <h2 className="login-title">Welcome Back</h2>
          <form onSubmit={handleSubmit} className="login-form">
            <label htmlFor="email" className="login-label">Email</label>
            <input
              type="email"
              id="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="login-input"
            />

            <label htmlFor="password" className="login-label">Password</label>
            <input
              type="password"
              id="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="login-input"
            />

            <button type="submit" className="login-button">Sign In</button>
          </form>
        </div>
      </div>
    </>
  );
}
